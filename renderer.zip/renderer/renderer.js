// === ICON COMPONENTS ===
const SearchIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <circle cx="11" cy="11" r="8" />
    <path d="m21 21-4.35-4.35" />
  </svg>
);
const PlusIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <line x1="12" y1="5" x2="12" y2="19" />
    <line x1="5" y1="12" x2="19" y2="12" />
  </svg>
);
const Trash2Icon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <polyline points="3 6 5 6 21 6" />
    <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
  </svg>
);
const Edit2Icon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z" />
  </svg>
);
const ExternalLinkIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" />
    <polyline points="15 3 21 3 21 9" />
    <line x1="10" y1="14" x2="21" y2="3" />
  </svg>
);
const StarIcon = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" strokeWidth="2">
    <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
  </svg>
);
const TrendingUpIcon = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <polyline points="23 6 13.5 15.5 8.5 10.5 1 18" />
    <polyline points="17 6 23 6 23 12" />
  </svg>
);
const ClockIcon = () => (
  <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <circle cx="12" cy="12" r="10" />
    <polyline points="12 6 12 12 16 14" />
  </svg>
);

// === MAIN COMPONENT ===
const AniWorld = () => {
  const [currentPage, setCurrentPage] = React.useState('home');
  const [searchQuery, setSearchQuery] = React.useState('');
  const [searchResults, setSearchResults] = React.useState([]);
  const [selectedItem, setSelectedItem] = React.useState(null);
  const [watchlist, setWatchlist] = React.useState([]);
  const [history, setHistory] = React.useState([]);
  const [editingItem, setEditingItem] = React.useState(null);
  const [isSearching, setIsSearching] = React.useState(false);
  const [topRated, setTopRated] = React.useState([]);
  const [popular, setPopular] = React.useState([]);
  const [loading, setLoading] = React.useState(true);

  // === SAFE FILTER ===
  const BLOCKED_GENRES = ['Hentai', 'Erotica', 'Ecchi'];
  const BLOCKED_RATINGS = ['Rx - Hentai'];
  const isContentSafe = (item) =>
    !(item.genres && item.genres.some(g => BLOCKED_GENRES.includes(g.name))) &&
    !(item.rating && BLOCKED_RATINGS.includes(item.rating));

  // === TRANSFORM FUNCTION ===
  const transformAnimeData = (item) => ({
    id: item.mal_id,
    title: item.title || item.title_english || 'Unknown',
    type: item.type === 'Manga' ? 'manga' : 'anime',
    score: item.score || 0,
    image: item.images?.jpg?.large_image_url || item.images?.jpg?.image_url || 'https://placehold.co/300x400/9333ea/ffffff?text=No+Image',
    popularity: item.popularity || 0,
    rank: item.rank || 0,
    genres: item.genres?.map(g => g.name) || [],
    synopsis: item.synopsis || 'No synopsis available.',
    producers: item.producers?.map(p => p.name) || item.serializations?.map(s => s.name) || [],
    source: item.source || 'Unknown',
    rating: item.rating || 'Not Rated',
    releases: item.aired?.string || item.published?.string || 'Unknown',
    malLink: item.url || `https://myanimelist.net/${item.type === 'Manga' ? 'manga' : 'anime'}/${item.mal_id}`,
    episodes: item.episodes || 0,
    chapters: item.chapters || 0,
    volumes: item.volumes || 0,
    status: item.status || 'Unknown'
  });

  // === FETCH HOME DATA ===
  React.useEffect(() => {
    const fetchTop = async () => {
      try {
        const a = await fetch('https://api.jikan.moe/v4/top/anime?limit=6');
        const ad = await a.json();
        const m = await fetch('https://api.jikan.moe/v4/top/manga?limit=6');
        const md = await m.json();
        const animeItems = (ad.data || []).filter(isContentSafe).map(transformAnimeData);
        const mangaItems = (md.data || []).filter(isContentSafe).map(transformAnimeData);
        setTopRated([...animeItems, ...mangaItems].slice(0, 6));
        setPopular(animeItems.slice(0, 6));
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    };
    fetchTop();
  }, []);

  // === SEARCH ===
  const handleSearch = async () => {
    if (!searchQuery.trim()) return;
    setIsSearching(true);
    try {
      const a = await fetch(`https://api.jikan.moe/v4/anime?q=${encodeURIComponent(searchQuery)}&limit=10&sfw=true`);
      const ad = await a.json();
      const m = await fetch(`https://api.jikan.moe/v4/manga?q=${encodeURIComponent(searchQuery)}&limit=10&sfw=true`);
      const md = await m.json();
      const results = [...(ad.data || []), ...(md.data || [])].filter(isContentSafe).map(transformAnimeData);
      setSearchResults(results);
    } catch (e) {
      console.error(e);
      alert('Search failed. Try again.');
    } finally {
      setIsSearching(false);
    }
  };

  // === DETAILS + HISTORY ===
  const showDetails = (item) => {
    setSelectedItem(item);
    if (!history.find(h => h.id === item.id)) {
      setHistory(prev => [{ ...item, viewedAt: new Date().toLocaleString() }, ...prev]);
    }
  };

  // === WATCHLIST ===
  const addToWatchlist = () => {
    if (!selectedItem) return;
    if (!watchlist.find(w => w.id === selectedItem.id)) {
      setWatchlist(prev => [...prev, {
        ...selectedItem,
        watched: 0,
        total: selectedItem.type === 'anime' ? (selectedItem.episodes || 12) : (selectedItem.chapters || 100),
        status: 'Watching',
        userScore: 10,
        review: ''
      }]);
      alert('Added to Watchlist!');
    } else {
      alert('Already in Watchlist!');
    }
  };
  const deleteFromWatchlist = (id) => setWatchlist(prev => prev.filter(i => i.id !== id));
  const deleteFromHistory = (id) => setHistory(prev => prev.filter(i => i.id !== id));
  const saveEdit = (updated) => {
    // ensure numeric fields
    const corrected = {
      ...updated,
      watched: parseInt(updated.watched, 10) || 0,
      total: parseInt(updated.total, 10) || (updated.type === 'anime' ? 12 : 100),
      userScore: parseInt(updated.userScore, 10) || 0
    };
    setWatchlist(prev => prev.map(i => i.id === corrected.id ? corrected : i));
    setEditingItem(null);
  };

  // === RENDER ===
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900 text-white">
      <header className="bg-black bg-opacity-50 border-b border-purple-500 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="text-4xl">📺</div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">AniWorld</h1>
          </div>
          <nav className="flex gap-4">
            {['home', 'watchlist', 'history'].map(p => (
              <button
                key={p}
                onClick={() => { setCurrentPage(p); setSelectedItem(null); setSearchResults([]); }}
                className={`px-4 py-2 rounded-lg font-semibold ${currentPage === p ? 'bg-purple-600' : 'hover:bg-purple-800'}`}>
                {p.charAt(0).toUpperCase() + p.slice(1)}
              </button>
            ))}
          </nav>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-6">
        {/* === HOME === */}
        {currentPage === 'home' && !selectedItem && (
          <>
            <div className="mb-6 flex gap-3">
              <div className="flex-1 relative">
                <div className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400"><SearchIcon /></div>
                <input
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                  placeholder="Search anime and manga..."
                  className="w-full pl-12 pr-4 py-3 bg-gray-800 border border-purple-500 rounded-lg text-white"
                />
              </div>
              <button onClick={handleSearch} disabled={isSearching} className="px-6 py-3 bg-purple-600 hover:bg-purple-700 rounded-lg font-semibold disabled:opacity-50">
                {isSearching ? 'Searching...' : 'Search'}
              </button>
            </div>

            {searchResults.length > 0 ? (
              <section className="mb-8">
                <h2 className="text-2xl font-bold mb-4 flex items-center gap-2"><SearchIcon /> Search Results ({searchResults.length})</h2>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {searchResults.map(item => <ItemCard key={item.id} item={item} onClick={() => showDetails(item)} />)}
                </div>
              </section>
            ) : (
              <>
                <section className="mb-8">
                  <h2 className="text-2xl font-bold mb-4 flex items-center gap-2 text-yellow-400"><StarIcon /> Top Rated</h2>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {topRated.map(item => <ItemCard key={item.id} item={item} onClick={() => showDetails(item)} />)}
                  </div>
                </section>

                <section>
                  <h2 className="text-2xl font-bold mb-4 flex items-center gap-2 text-green-400"><TrendingUpIcon /> Popular</h2>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {popular.map(item => <ItemCard key={item.id} item={item} onClick={() => showDetails(item)} />)}
                  </div>
                </section>
              </>
            )}
          </>
        )}

        {/* === DETAILS === */}
        {selectedItem && (
          <Details item={selectedItem} back={() => setSelectedItem(null)} add={addToWatchlist} />
        )}

        {/* === WATCHLIST === */}
        {currentPage === 'watchlist' && (
          <div>
            <h2 className="text-2xl font-bold mb-4 flex items-center gap-2 text-purple-400"><ClockIcon /> My Watchlist</h2>
            {watchlist.length === 0 ? (
              <p className="text-gray-400">No items added yet. Add from the home page.</p>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {watchlist.map(item => (
                  <div key={item.id} className="bg-gray-800 rounded-lg p-4 flex gap-4 items-start">
                    <img src={item.image} alt={item.title} className="w-24 h-32 object-cover rounded flex-shrink-0" />
                    <div className="flex-1">
                      <div className="flex items-start justify-between">
                        <div>
                          <h3 className="font-semibold text-lg">{item.title}</h3>
                          <p className="text-sm text-gray-400">{item.type.toUpperCase()} • {item.genres?.slice(0,2).join(', ')}</p>
                        </div>
                        <div className="text-yellow-400 font-bold">★ {item.userScore ?? item.score}</div>
                      </div>

                      <div className="mt-3 grid grid-cols-2 gap-2 text-sm">
                        <div>
                          <div className="text-xs text-gray-400">Status</div>
                          <div className="font-semibold">{item.status}</div>
                        </div>
                        <div>
                          <div className="text-xs text-gray-400">{item.type === 'anime' ? 'Episodes' : 'Chapters'}</div>
                          <div className="font-semibold">{item.watched}/{item.total}</div>
                        </div>
                      </div>

                      <div className="flex gap-2 mt-3">
                        <button onClick={() => setEditingItem(item)} className="flex items-center gap-2 px-3 py-1 bg-yellow-600 hover:bg-yellow-700 rounded">
                          <Edit2Icon /> Edit
                        </button>
                        <button onClick={() => { if (confirm('Remove from watchlist?')) deleteFromWatchlist(item.id); }} className="flex items-center gap-2 px-3 py-1 bg-red-600 hover:bg-red-700 rounded">
                          <Trash2Icon /> Delete
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* === HISTORY === */}
        {currentPage === 'history' && (
          <div>
            <h2 className="text-2xl font-bold mb-4 text-pink-400">History</h2>
            {history.length === 0 ? (
              <p className="text-gray-400">No history yet. View an item to add it to history.</p>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {history.map((item, idx) => (
                  <div key={`${item.id}-${idx}`} className="bg-gray-800 rounded-lg p-4 flex items-start gap-4">
                    <img src={item.image} alt={item.title} className="w-20 h-28 object-cover rounded flex-shrink-0" />
                    <div className="flex-1">
                      <div className="flex items-start justify-between">
                        <div>
                          <h3 className="font-semibold">{item.title}</h3>
                          <p className="text-sm text-gray-400">{item.type.toUpperCase()} • Viewed: {item.viewedAt}</p>
                        </div>
                        <div className="text-yellow-400 font-bold">★ {item.score}</div>
                      </div>

                      <div className="flex gap-2 mt-3">
                        <button onClick={() => showDetails(item)} className="text-purple-400 hover:text-purple-300 text-sm">View</button>
                        <button onClick={() => { if (confirm('Delete this history item?')) deleteFromHistory(item.id); }} className="text-red-400 hover:text-red-300 text-sm">Delete</button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* === EDIT MODAL === */}
        {editingItem && (
          <EditModal
            item={editingItem}
            onSave={saveEdit}
            onCancel={() => setEditingItem(null)}
          />
        )}
      </main>
    </div>
  );
};

// === SUB COMPONENTS ===
const ItemCard = ({ item, onClick }) => (
  <div onClick={onClick} className="cursor-pointer bg-gray-800 rounded-lg overflow-hidden hover:scale-105 transition-transform">
    <div className="aspect-[3/4] bg-gray-700 overflow-hidden">
      <img src={item.image} alt={item.title} className="w-full h-full object-cover" />
    </div>
    <div className="p-3">
      <h3 className="font-semibold text-sm mb-1 truncate">{item.title}</h3>
      <div className="text-xs text-gray-400">{item.type?.toUpperCase() || ''} • ★ {item.score}</div>
    </div>
  </div>
);

const Details = ({ item, back, add }) => (
  <div className="bg-gray-800 rounded-lg p-6">
    <button onClick={back} className="mb-4 text-purple-400 hover:text-purple-300">← Back</button>
    <div className="flex gap-6">
      <div className="w-48 h-64 rounded overflow-hidden flex-shrink-0">
        <img src={item.image} alt={item.title} className="w-full h-full object-cover" />
      </div>
      <div className="flex-1">
        <div className="flex items-start justify-between mb-4">
          <div>
            <h1 className="text-3xl font-bold mb-2">{item.title}</h1>
            <span className="inline-block px-3 py-1 bg-purple-600 rounded-full text-sm font-semibold">{item.type?.toUpperCase()}</span>
          </div>
          <div className="text-right">
            <div className="text-3xl font-bold text-yellow-400">★ {item.score}</div>
            <div className="text-sm text-gray-400">Score</div>
          </div>
        </div>

        <div className="mb-4">
          <h3 className="font-semibold mb-2">Synopsis</h3>
          <p className="text-gray-300 text-sm leading-relaxed">{item.synopsis}</p>
        </div>

        <div className="flex gap-3">
          <button onClick={add} className="flex items-center gap-2 px-6 py-3 bg-purple-600 hover:bg-purple-700 rounded-lg font-semibold"><PlusIcon /> Add to Watchlist</button>
          <a href={item.malLink} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 px-6 py-3 bg-blue-600 hover:bg-blue-700 rounded-lg font-semibold">
            <ExternalLinkIcon /> View on MAL
          </a>
        </div>
      </div>
    </div>
  </div>
);

const EditModal = ({ item, onSave, onCancel }) => {
  const [edited, setEdited] = React.useState({
    ...item,
    // ensure fields exist
    watched: item.watched ?? 0,
    total: item.total ?? (item.type === 'anime' ? (item.episodes || 12) : (item.chapters || 100)),
    userScore: item.userScore ?? item.userScore ?? item.score ?? 10,
    review: item.review ?? ''
  });

  React.useEffect(() => {
    setEdited(prev => ({ ...prev, id: item.id })); // ensure id kept if item changes
  }, [item.id]);

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 flex justify-center items-center z-50 p-4">
      <div className="bg-gray-900 p-6 rounded-lg w-full max-w-md">
        <h3 className="text-xl font-bold mb-4 text-purple-400">Edit — {item.title}</h3>

        <label className="block text-sm text-gray-300 mb-1">Status</label>
        <select
          value={edited.status}
          onChange={(e) => setEdited({ ...edited, status: e.target.value })}
          className="w-full p-2 rounded bg-gray-800 border border-purple-500 mb-3"
        >
          {['Watching','Completed','On Hold','Dropped','Plan to Watch'].map(s => <option key={s}>{s}</option>)}
        </select>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-sm text-gray-300 mb-1">Progress</label>
            <input
              type="number"
              min="0"
              value={edited.watched}
              onChange={(e) => setEdited({ ...edited, watched: parseInt(e.target.value || '0', 10) })}
              className="w-full p-2 rounded bg-gray-800 border border-gray-700"
            />
            <div className="text-xs text-gray-400 mt-1">/ {edited.total}</div>
          </div>

          <div>
            <label className="block text-sm text-gray-300 mb-1">Total</label>
            <input
              type="number"
              min="1"
              value={edited.total}
              onChange={(e) => setEdited({ ...edited, total: parseInt(e.target.value || '0', 10) })}
              className="w-full p-2 rounded bg-gray-800 border border-gray-700"
            />
          </div>
        </div>

        <label className="block text-sm text-gray-300 mt-3 mb-1">Your Score</label>
        <select
          value={edited.userScore}
          onChange={(e) => setEdited({ ...edited, userScore: parseInt(e.target.value, 10) })}
          className="w-full p-2 rounded bg-gray-800 border border-purple-500"
        >
          {[10,9,8,7,6,5,4,3,2,1].map(n => (
            <option key={n} value={n}>{n} — {n === 10 ? 'Masterpiece' : n >= 8 ? 'Great' : n >= 6 ? 'Good' : 'Average'}</option>
          ))}
        </select>

        <label className="block text-sm text-gray-300 mt-3 mb-1">Review (optional)</label>
        <textarea
          rows="4"
          value={edited.review}
          onChange={(e) => setEdited({ ...edited, review: e.target.value })}
          className="w-full p-2 rounded bg-gray-800 border border-gray-700 resize-none"
          placeholder="Write a short note or review..."
        />

        <div className="flex justify-end gap-2 mt-4">
          <button onClick={() => onCancel()} className="px-4 py-2 bg-gray-700 hover:bg-gray-600 rounded">Cancel</button>
          <button
            onClick={() => {
              // basic validation: watched cannot exceed total
              if ((edited.watched || 0) > (edited.total || 0)) {
                if (!confirm('Watched is greater than Total. Save anyway?')) return;
              }
              onSave(edited);
            }}
            className="px-4 py-2 bg-green-600 hover:bg-green-700 rounded"
          >
            Save Changes
          </button>
        </div>
      </div>
    </div>
  );
};

// === INIT RENDER ===
ReactDOM.createRoot(document.getElementById('root')).render(<AniWorld />);
