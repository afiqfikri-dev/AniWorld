// index.js - homepage logic (top + search + add + details)
const content = document.getElementById("content");
const searchInput = document.getElementById("searchInput");
const detailOverlay = document.getElementById("detailOverlay");
const detailCard = document.getElementById("detailCard");
const homeBtn = document.getElementById("homeBtn");
const watchlistBtn = document.getElementById("watchlistBtn");

homeBtn?.addEventListener("click", ()=> window.location.href = "index.html");
watchlistBtn?.addEventListener("click", ()=> window.location.href = "watchlist.html");

let watchlist = JSON.parse(localStorage.getItem("watchlist") || "[]");

// debounce helper
function debounce(fn, wait=350){
  let t;
  return (...args)=>{ clearTimeout(t); t = setTimeout(()=>fn(...args), wait); }
}

function escapeHtml(s){ if(s===undefined||s===null) return ""; return String(s).replace(/[&<>"']/g, ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch])); }

function showLoading(targetEl, text="Loading..."){ targetEl.innerHTML = `<p style="text-align:center;opacity:0.7;">${text}</p>`; }

// render cards
function renderCards(list, targetEl){
  if(!list || list.length===0){ targetEl.innerHTML = `<p style="text-align:center;opacity:0.7;">No results.</p>`; return; }
  const items = list.slice(0, 30);
  targetEl.innerHTML = items.map(item => {
    const type = item._type || item.type || (item.volumes ? "Manga" : "Anime");
    const badgeClass = (String(type).toLowerCase().includes("manga")) ? "manga":"anime";
    const inWL = watchlist.some(w => w.mal_id === item.mal_id);
    const img = item.images?.jpg?.large_image_url || "";
    return `
      <div class="anime-card" data-id="${item.mal_id}">
        <img loading="lazy" src="${img}" alt="${escapeHtml(item.title)}" />
        <div class="anime-info">
          <span class="type-badge ${badgeClass}">${type}</span>
          <h3>${escapeHtml(item.title)}</h3>
          <p>Score: ${item.score ?? "N/A"}</p>
          <div class="buttons-row">
            <button class="details-btn">Details</button>
            <button class="add-btn" ${inWL? "disabled": ""}>${inWL? "Added ✓":"Add to Watchlist"}</button>
          </div>
        </div>
      </div>
    `;
  }).join("");

  // attach events
  targetEl.querySelectorAll(".anime-card").forEach((card, idx)=>{
    const item = items[idx];
    const detailsBtn = card.querySelector(".details-btn");
    const addBtn = card.querySelector(".add-btn");
    detailsBtn?.addEventListener("click", ()=> showDetails(item));
    addBtn?.addEventListener("click", ()=> addToWatchlist(item));
  });
}

// load top anime + manga
async function loadTop(){
  showLoading(content, "Loading top anime & manga...");
  try{
    const [aRes, mRes] = await Promise.all([
      fetch("https://api.jikan.moe/v4/top/anime?limit=20").then(r=>r.json()),
      fetch("https://api.jikan.moe/v4/top/manga?limit=20").then(r=>r.json())
    ]);
    const anime = (aRes.data || []).map(x=> ({...x, _type:"Anime"}));
    const manga = (mRes.data || []).map(x=> ({...x, _type:"Manga"}));
    const combined = [...anime, ...manga].filter(i => i.score && i.score >= 7).sort((a,b)=>(b.score||0)-(a.score||0));
    renderCards(combined, content);
  }catch(err){
    console.error("loadTop error", err);
    content.innerHTML = `<p style="text-align:center;color:red;">Failed to load top lists.</p>`;
  }
}

// search anime + manga
const doSearch = debounce(async (q)=>{
  if(!q || q.length < 3){ return loadTop(); }
  showLoading(content, `Searching "${escapeHtml(q)}"...`);
  try{
    const [aRes, mRes] = await Promise.all([
      fetch(`https://api.jikan.moe/v4/anime?q=${encodeURIComponent(q)}&limit=15`).then(r=>r.json()),
      fetch(`https://api.jikan.moe/v4/manga?q=${encodeURIComponent(q)}&limit=15`).then(r=>r.json())
    ]);
    const anime = (aRes.data||[]).map(x=>({...x,_type:"Anime"}));
    const manga = (mRes.data||[]).map(x=>({...x,_type:"Manga"}));
    const combined = [...anime, ...manga];
    renderCards(combined, content);
  }catch(err){
    console.error("search error", err);
    content.innerHTML = `<p style="text-align:center;color:red;">Search failed.</p>`;
  }
}, 400);

searchInput.addEventListener("input", (e)=> doSearch(e.target.value.trim()));

// details modal
async function showDetails(item){
  try{
    // fetch full details to get producers, genres, aired/published, etc.
    const type = (item._type || item.type || (item.volumes? "Manga":"Anime")).toLowerCase();
    const res = await fetch(`https://api.jikan.moe/v4/${type}/${item.mal_id}`);
    if(!res.ok) throw new Error("detail fetch failed");
    const data = (await res.json()).data;
    const genres = (data.genres||[]).map(g=>g.name).join(", ") || "N/A";
    const producers = (data.producers||[]).map(p=>p.name).join(", ") || (data.authors||[]).map(a=>a.name).join(", ") || "N/A";
    const release = data.aired?.string || data.published?.string || "N/A";
    const typeLabel = (item._type || item.type || (item.volumes? "Manga":"Anime"));
    const html = `
      <button class="close-btn" id="closeDetailBtn">✖</button>
      <img src="${data.images?.jpg?.large_image_url || ""}" alt="${escapeHtml(data.title)}" />
      <h2>${escapeHtml(data.title)}</h2>
      <p><strong>Type:</strong> ${typeLabel}</p>
      <p><strong>Score:</strong> ${data.score ?? "N/A"}</p>
      <p><strong>Rank:</strong> ${data.rank ?? "N/A"} | <strong>Popularity:</strong> ${data.popularity ?? "N/A"}</p>
      <p><strong>Genres:</strong> ${escapeHtml(genres)}</p>
      <p><strong>Producers/Authors:</strong> ${escapeHtml(producers)}</p>
      <p><strong>Source:</strong> ${data.source ?? "N/A"} | <strong>Rating:</strong> ${data.rating ?? "N/A"}</p>
      <p><strong>Releases & Schedules:</strong> ${escapeHtml(release)}</p>
      <p style="margin-top:8px;">${escapeHtml(data.synopsis || "No synopsis available.")}</p>
      <a href="${data.url}" target="_blank">View on MyAnimeList →</a>
    `;
    detailCard.innerHTML = html;
    detailOverlay.classList.add("active");
    document.getElementById("closeDetailBtn").addEventListener("click", closeDetailModal);
  }catch(err){
    console.error("showDetails error", err);
    alert("Failed to load details.");
  }
}

function closeDetailModal(){
  detailOverlay.classList.remove("active");
  detailCard.innerHTML = "";
}

// add to watchlist (fetch totals & store)
async function addToWatchlist(item){
  if(watchlist.some(x=>x.mal_id===item.mal_id)){ alert("Already in watchlist."); return; }
  try{
    const type = (item._type || item.type || (item.volumes? "Manga":"Anime")).toLowerCase();
    const res = await fetch(`https://api.jikan.moe/v4/${type}/${item.mal_id}`);
    if(!res.ok) throw new Error("detail fetch failed");
    const data = (await res.json()).data;
    const totalEpisodes = (type==="anime") ? (data.episodes || 0) : 0;
    const totalChapters = (type==="manga") ? (data.chapters || 0) : 0;

    const store = {
      mal_id: data.mal_id,
      title: data.title,
      image: data.images?.jpg?.large_image_url || item.images?.jpg?.large_image_url || "",
      type: (type==="manga") ? "Manga" : "Anime",
      score: data.score || item.score || null,
      url: data.url || item.url || "",
      synopsis: data.synopsis || item.synopsis || "",
      totalEpisodes: totalEpisodes || 0,
      totalChapters: totalChapters || 0,
      watched: 0,
      review: ""
    };
    watchlist.push(store);
    localStorage.setItem("watchlist", JSON.stringify(watchlist));
    alert(`${store.title} added to watchlist.`);
    loadTop();
  }catch(err){
    console.error("addToWatchlist error", err);
    alert("Failed to add to watchlist.");
  }
}

// start
loadTop();
